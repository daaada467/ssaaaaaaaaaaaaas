package com.veritymod;

import com.veritymod.command.SpawnVerityCommand;
import com.veritymod.entity.ModEntities;
import com.veritymod.sound.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import com.veritymod.entity.VerityEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class VerityMod implements ModInitializer {
    public static final String MOD_ID = "veritymod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final Set<UUID> PLAYERS_WITH_VERITY = new HashSet<>();

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModSounds.register();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                SpawnVerityCommand.register(dispatcher));
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            for (class_3222 player : world.method_18456()) {
                if (player.field_6012 > 20 && !PLAYERS_WITH_VERITY.contains(player.method_5667())) {
                    spawnInitialVerity(player);
                }
            }
        });
        // Right-click a block while carrying Verity to put her down there.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != class_1268.field_5808 || player.method_7325()) return class_1269.field_5811;
            VerityEntity carried = VerityEntity.findCarriedBy(player);
            if (carried == null) return class_1269.field_5811;
            if (!world.field_9236) {
                class_2338 pos = hit.method_17777().method_10093(hit.method_17780());
                if (!world.method_8320(pos).method_26220(world, pos).method_1110()) pos = pos.method_10084();
                carried.placeDown(class_243.method_24955(pos));
            }
            return class_1269.field_5812;
        });
        LOGGER.info("Verity initialized");
    }

    private static void spawnInitialVerity(class_3222 player) {
        class_238 searchArea = player.method_5829().method_1014(32.0);
        boolean alreadyPresent = !player.method_51469().method_18023(
                ModEntities.VERITY,
                searchArea,
                entity -> entity.method_5805()
        ).isEmpty();
        if (alreadyPresent) return;

        var verity = ModEntities.VERITY.method_5883(player.method_51469());
        if (verity == null) {
            LOGGER.error("Не удалось создать EntityType verity");
            return;
        }
        verity.method_5808(player.method_23317(), player.method_23318() + 0.15, player.method_23321(), player.method_36454(), 0.0f);
        if (player.method_51469().method_8649(verity)) {
            PLAYERS_WITH_VERITY.add(player.method_5667());
            LOGGER.info("Verity box spawned for {} at {}, {}, {}", player.method_5477().getString(), player.method_31477(), player.method_31478(), player.method_31479());
        }
    }
}
