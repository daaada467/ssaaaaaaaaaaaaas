package com.veritymod.sound;

import com.veritymod.VerityMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class ModSounds {
    public static final class_3414 VERITY_GREETING = register("verity_greeting");
    private static class_3414 register(String id) {
        class_2960 identifier = class_2960.method_60655(VerityMod.MOD_ID, id);
        return class_2378.method_10230(class_7923.field_41172, identifier, class_3414.method_47908(identifier));
    }
    public static void register() {}
}
