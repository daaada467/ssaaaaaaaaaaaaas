package com.veritymod.command;

import com.veritymod.entity.ModEntities;
import com.veritymod.entity.VerityEntity;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import com.mojang.brigadier.CommandDispatcher;

public final class SpawnVerityCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("spawnverity")
                .executes(context -> {
                    class_3222 player = context.getSource().method_44023();
                    if (player == null) return 0;
                    VerityEntity entity = ModEntities.VERITY.method_5883(player.method_37908());
                    if (entity == null) return 0;
                    entity.method_5808(player.method_23317(), player.method_23318() + 1.0, player.method_23321(), player.method_36454(), 0);
                    player.method_37908().method_8649(entity);
                    context.getSource().method_9226(() -> class_2561.method_43470("Verity появилась рядом с игроком"), false);
                    return 1;
                }));
    }
}
