package com.veritymod.entity;

import com.veritymod.VerityMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

public final class ModEntities {
    public static final class_1299<VerityEntity> VERITY = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(VerityMod.MOD_ID, "verity"),
            FabricEntityTypeBuilder.create(class_1311.field_17715, VerityEntity::new)
                    .dimensions(class_4048.method_18385(1.0f, 1.0f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(1)
                    .fireImmune()
                    .build()
    );

    private ModEntities() {}
    public static void register() {
        FabricDefaultAttributeRegistry.register(VERITY, VerityEntity.createVerityAttributes().method_26866());
    }
}
