package com.veritymod.entity.renderer;

import com.veritymod.VerityMod;
import com.veritymod.entity.VerityEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;

/**
 * Verity: a smooth yellow 3D ball with a face built from geometry
 * (no textures with backgrounds, so no gray/orange halos or seams).
 * Box: a taped cardboard cuboid whose lid flaps burst open on release.
 */
public class VerityEntityRenderer extends class_897<VerityEntity> {
    private static final class_2960 WHITE = class_2960.method_60655(VerityMod.MOD_ID, "textures/entity/verity_white.png");
    private static final class_2960 BOX = class_2960.method_60655(VerityMod.MOD_ID, "textures/entity/verity_box.png");

    private static final float R = 0.45f;             // ball radius (0.9 block diameter)
    private static final int LAT = 24, LON = 40;      // ball smoothness
    private static final float[][] SPHERE = buildSphere();

    private static final int[] YELLOW = {255, 222, 0};
    private static final int[] BLACK = {20, 20, 20};
    private static final int[] TONGUE = {255, 238, 110};

    public VerityEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.field_4673 = 0.45f;
        this.field_4672 = 0.6f;
    }

    @Override
    public class_2960 getTexture(VerityEntity entity) {
        return entity.isInBox() ? BOX : WHITE;
    }

    @Override
    public void render(VerityEntity entity, float yaw, float tickDelta, class_4587 matrices,
                       class_4597 providers, int light) {
        float lookYaw = class_3532.method_17821(tickDelta, entity.field_6259, entity.field_6241);

        if (entity.isInBox()) {
            matrices.method_22903();
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-lookYaw));
            renderBox(matrices, providers.getBuffer(class_1921.method_23578(BOX)), light, 0f);
            matrices.method_22909();
            super.method_3936(entity, yaw, tickDelta, matrices, providers, light);
            return;
        }

        float anim = entity.getReleaseAnim(tickDelta);
        float t = entity.field_6012 + tickDelta;

        // ---- the box during the release animation: shake, flaps burst open, then it vanishes
        if (anim >= 0f && anim < 20f) {
            matrices.method_22903();
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-lookYaw));
            if (anim < 3f) {
                float d = 1f - anim / 3f;
                matrices.method_22907(class_7833.field_40718.rotationDegrees(class_3532.method_15374(anim * 5f) * 9f * d));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(class_3532.method_15362(anim * 4f) * 5f * d));
                matrices.method_22905(1f, 1f + 0.07f * class_3532.method_15374(anim * 5f) * d, 1f);
            }
            if (anim > 17f) {
                float k = Math.max(0.001f, 1f - (anim - 17f) / 3f);
                matrices.method_22905(k, k, k);
            }
            float flap = anim < 2f ? 0f : easeOutBack(class_3532.method_15363((anim - 2f) / 3f, 0f, 1f)) * 125f;
            renderBox(matrices, providers.getBuffer(class_1921.method_23578(BOX)), light, Math.max(0.01f, flap));
            matrices.method_22909();
        }

        class_4588 vc = providers.getBuffer(class_1921.method_23578(WHITE));
        float pitch = class_3532.method_15363(entity.method_5695(tickDelta), -40f, 40f) * 0.6f;

        // ---- carried in the player's hand
        if (entity.isCarried()) {
            class_1297 carrier = entity.getCarrier();
            if (carrier instanceof class_1657 player) {
                class_243 c = VerityEntity.carryPos(player, tickDelta);
                double ex = class_3532.method_16436(tickDelta, entity.field_6038, entity.method_23317());
                double ey = class_3532.method_16436(tickDelta, entity.field_5971, entity.method_23318());
                double ez = class_3532.method_16436(tickDelta, entity.field_5989, entity.method_23321());
                matrices.method_22903();
                matrices.method_22904(c.field_1352 - ex, c.field_1351 - ey - (R + FOOT_LIFT) * VerityEntity.CARRY_SCALE, c.field_1350 - ez);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-lookYaw));
                matrices.method_22905(VerityEntity.CARRY_SCALE, VerityEntity.CARRY_SCALE, VerityEntity.CARRY_SCALE);
                // dangling feet that sway a little
                float sway = class_3532.method_15374(t * 0.25f) * 0.04f;
                renderFeet(matrices.method_23760(), vc, light, sway, -sway, 0f, 0f);
                matrices.method_22904(0.0, FOOT_LIFT, 0.0);
                tiltAndDrawBall(matrices, vc, light, entity, pitch);
                matrices.method_22909();
                super.method_3936(entity, yaw, tickDelta, matrices, providers, light);
                return;
            }
        }

        // ---- Verity: launch out of the box, land on its lid, hop down to the ground
        float y = 0.0f, sy = 1f, sxz = 1f, spin = 0f, grow = 1f;
        boolean visible = true;
        float bob = class_3532.method_15374(t * 0.12f) * 0.02f;
        if (anim < 0f) {
            y += bob;
        } else if (anim < 4f) {
            visible = false;
        } else if (anim < 14f) {
            float s = (anim - 4f) / 10f;
            float h = 1.2f;
            y = class_3532.method_16439(s, 0.05f, BY) + 4f * h * s * (1f - s);
            float v = ((BY - 0.05f) + 4f * h * (1f - 2f * s)) / (4f * h);
            sy = 1f + 0.22f * Math.abs(v);
            sxz = 1f / (float) Math.sqrt(sy);
            spin = 360f * easeOutCubic(s);
            grow = class_3532.method_15363(0.55f + s * 1.2f, 0f, 1f);
        } else if (anim < 20f) {
            y = BY;
            float k = anim - 14f;
            sy = wobble(k, 0.30f);
            sxz = 1f + (1f - sy) * 0.7f;
        } else if (anim < 24f) {
            float s = (anim - 20f) / 4f;
            y = BY + (0.0f - BY) * s * s;
            sy = 1f + 0.12f * s;
            sxz = 1f / (float) Math.sqrt(sy);
        } else {
            float k = anim - 24f;
            sy = wobble(k, 0.22f);
            sxz = 1f + (1f - sy) * 0.7f;
            y = bob * class_3532.method_15363(k / 12f, 0f, 1f);
        }

        // landing squash after falls, bounces and knockback
        float land = entity.getLandAnim(tickDelta);
        if (anim < 0f && land >= 0f && land < 14f) {
            float w = wobble(land, entity.getLandAmp());
            sy *= w;
            sxz *= 1f + (1f - w) * 0.7f;
        }

        if (visible) {
            // walking: alternating feet, side-to-side waddle and a small step bounce
            float limbPos = entity.field_42108.method_48572(tickDelta);
            float limbSpeed = class_3532.method_15363(entity.field_42108.method_48570(tickDelta), 0f, 1f);
            float phase = limbPos * 0.6662f;
            float stepL = class_3532.method_15362(phase) * 0.16f * limbSpeed;
            float stepR = -stepL;
            float liftL = Math.max(0f, class_3532.method_15374(phase)) * 0.07f * limbSpeed;
            float liftR = Math.max(0f, -class_3532.method_15374(phase)) * 0.07f * limbSpeed;
            float stepBounce = Math.abs(class_3532.method_15374(phase)) * 0.05f * limbSpeed;
            float waddle = class_3532.method_15374(phase) * 7f * limbSpeed;

            matrices.method_22903();
            matrices.method_22904(0.0, y, 0.0);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-lookYaw - spin));
            matrices.method_22905(grow, grow, grow);
            renderFeet(matrices.method_23760(), vc, light, stepL, stepR, liftL, liftR);

            matrices.method_22904(0.0, FOOT_LIFT + stepBounce, 0.0);
            matrices.method_22907(class_7833.field_40718.rotationDegrees(waddle));
            // squash & stretch around the bottom of the ball
            matrices.method_22905(sxz, sy, sxz);
            tiltAndDrawBall(matrices, vc, light, entity, pitch);
            matrices.method_22909();
        }

        super.method_3936(entity, yaw, tickDelta, matrices, providers, light);
    }

    private static void tiltAndDrawBall(class_4587 matrices, class_4588 vc, int light,
                                        VerityEntity entity, float pitch) {
        matrices.method_22903();
        matrices.method_22904(0.0, R, 0.0);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
        if (entity.isMouthOpen()) {
            matrices.method_22905(1.03f, 0.97f, 1.03f);
        }
        matrices.method_22904(0.0, -R, 0.0);
        renderVerity(matrices.method_23760(), vc, light, entity.isMouthOpen());
        matrices.method_22909();
    }

    // ------------------------------------------------------------------- feet

    private static final float FOOT_LIFT = 0.07f;
    private static final int[] FOOT = {235, 168, 0};

    private static void renderFeet(class_4587.class_4665 e, class_4588 vc, int light,
                                   float stepL, float stepR, float liftL, float liftR) {
        ellipsoid(e, vc, light, -0.17f, 0.055f + liftL, 0.04f + stepL, 0.10f, 0.055f, 0.15f, FOOT);
        ellipsoid(e, vc, light, 0.17f, 0.055f + liftR, 0.04f + stepR, 0.10f, 0.055f, 0.15f, FOOT);
    }

    private static void ellipsoid(class_4587.class_4665 e, class_4588 vc, int light,
                                  float cx, float cy, float cz, float rx, float ry, float rz, int[] col) {
        for (int i = 0; i < LAT; i += 2) {
            for (int j = 0; j < LON; j += 2) {
                ellipsoidVertex(e, vc, light, SPHERE[i * (LON + 1) + j], cx, cy, cz, rx, ry, rz, col);
                ellipsoidVertex(e, vc, light, SPHERE[(i + 2) * (LON + 1) + j], cx, cy, cz, rx, ry, rz, col);
                ellipsoidVertex(e, vc, light, SPHERE[(i + 2) * (LON + 1) + j + 2], cx, cy, cz, rx, ry, rz, col);
                ellipsoidVertex(e, vc, light, SPHERE[i * (LON + 1) + j + 2], cx, cy, cz, rx, ry, rz, col);
            }
        }
    }

    private static void ellipsoidVertex(class_4587.class_4665 e, class_4588 vc, int light, float[] n,
                                        float cx, float cy, float cz, float rx, float ry, float rz, int[] col) {
        float nx = n[0] / rx, ny = n[1] / ry, nz = n[2] / rz;
        float len = class_3532.method_15355(nx * nx + ny * ny + nz * nz);
        vertex(e, vc, cx + n[0] * rx, cy + n[1] * ry, cz + n[2] * rz, nx / len, ny / len, nz / len, 0.5f, 0.5f, col, light);
    }

    private static float wobble(float k, float amp) {
        return 1f - amp * (float) Math.exp(-k * 0.45f) * class_3532.method_15362(k * 1.5f);
    }

    private static float easeOutCubic(float x) {
        float i = 1f - x;
        return 1f - i * i * i;
    }

    private static float easeOutBack(float x) {
        float c1 = 1.70158f, c3 = c1 + 1f;
        float m = x - 1f;
        return 1f + c3 * m * m * m + c1 * m * m;
    }

    // ------------------------------------------------------------------ Verity

    private static float[][] buildSphere() {
        float[][] pts = new float[(LAT + 1) * (LON + 1)][];
        for (int i = 0; i <= LAT; i++) {
            double th = Math.PI * i / LAT;
            for (int j = 0; j <= LON; j++) {
                double ph = 2 * Math.PI * j / LON;
                float nx = (float) (Math.sin(th) * Math.sin(ph));
                float ny = (float) Math.cos(th);
                float nz = (float) (Math.sin(th) * Math.cos(ph));
                pts[i * (LON + 1) + j] = new float[]{nx, ny, nz};
            }
        }
        return pts;
    }

    private static void renderVerity(class_4587.class_4665 e, class_4588 vc, int light, boolean open) {
        // Body
        for (int i = 0; i < LAT; i++) {
            for (int j = 0; j < LON; j++) {
                float[] a = SPHERE[i * (LON + 1) + j];
                float[] b = SPHERE[(i + 1) * (LON + 1) + j];
                float[] c = SPHERE[(i + 1) * (LON + 1) + j + 1];
                float[] d = SPHERE[i * (LON + 1) + j + 1];
                ballVertex(e, vc, a, R, YELLOW, light);
                ballVertex(e, vc, b, R, YELLOW, light);
                ballVertex(e, vc, c, R, YELLOW, light);
                ballVertex(e, vc, d, R, YELLOW, light);
            }
        }

        float face = R + 0.004f;
        // Eyes: small vertical ovals, close together (like the original 2D face)
        ellipse(e, vc, light, -0.13f, 0.17f, 0.042f, 0.075f, face, BLACK);
        ellipse(e, vc, light, 0.13f, 0.17f, 0.042f, 0.075f, face, BLACK);

        if (!open) {
            // Closed: thin smile, thicker in the middle
            final float w = 0.32f;
            patch(e, vc, light, -w, w,
                    a -> smile(a, w) + smileHalf(a, w),
                    a -> smile(a, w) - smileHalf(a, w),
                    face, BLACK);
        } else {
            // Open: "D"-shaped mouth with a tongue
            final float w = 0.30f;
            patch(e, vc, light, -w, w,
                    a -> -0.07f + 0.035f * (a / w) * (a / w),
                    a -> -0.07f - 0.20f * root(a / w),
                    face, BLACK);
            ellipse(e, vc, light, 0.0f, -0.225f, 0.12f, 0.042f, R + 0.008f, TONGUE);
        }
    }

    private static float smile(float a, float w) {
        float k = a / w;
        return -0.10f - 0.10f * (1 - k * k);
    }

    private static float smileHalf(float a, float w) {
        return 0.012f + 0.012f * root(a / w);
    }

    private static float root(float k) {
        return (float) Math.sqrt(Math.max(0f, 1f - k * k));
    }

    private interface Curve {
        float at(float a);
    }

    private static void ellipse(class_4587.class_4665 e, class_4588 vc, int light,
                                float ca, float cb, float w, float h, float radius, int[] col) {
        patch(e, vc, light, ca - w, ca + w,
                a -> cb + h * root((a - ca) / w),
                a -> cb - h * root((a - ca) / w),
                radius, col);
    }

    /** Fills the region between two curves on the sphere, in (yaw a, pitch b) angles. */
    private static void patch(class_4587.class_4665 e, class_4588 vc, int light,
                              float aMin, float aMax, Curve top, Curve bottom, float radius, int[] col) {
        final int cols = 20, rows = 4;
        for (int i = 0; i < cols; i++) {
            float a0 = aMin + (aMax - aMin) * i / cols;
            float a1 = aMin + (aMax - aMin) * (i + 1) / cols;
            float t0 = top.at(a0), b0 = bottom.at(a0);
            float t1 = top.at(a1), b1 = bottom.at(a1);
            for (int j = 0; j < rows; j++) {
                float f0 = (float) j / rows, f1 = (float) (j + 1) / rows;
                surfaceVertex(e, vc, a0, class_3532.method_16439(f0, t0, b0), radius, col, light);
                surfaceVertex(e, vc, a0, class_3532.method_16439(f1, t0, b0), radius, col, light);
                surfaceVertex(e, vc, a1, class_3532.method_16439(f1, t1, b1), radius, col, light);
                surfaceVertex(e, vc, a1, class_3532.method_16439(f0, t1, b1), radius, col, light);
            }
        }
    }

    private static void surfaceVertex(class_4587.class_4665 e, class_4588 vc, float a, float b,
                                      float radius, int[] col, int light) {
        float cb = class_3532.method_15362(b);
        float nx = class_3532.method_15374(a) * cb, ny = class_3532.method_15374(b), nz = class_3532.method_15362(a) * cb;
        vertex(e, vc, nx * radius, R + ny * radius, nz * radius, nx, ny, nz, 0.5f, 0.5f, col, light);
    }

    private static void ballVertex(class_4587.class_4665 e, class_4588 vc, float[] n, float radius,
                                   int[] col, int light) {
        vertex(e, vc, n[0] * radius, R + n[1] * radius, n[2] * radius, n[0], n[1], n[2], 0.5f, 0.5f, col, light);
    }

    // --------------------------------------------------------------------- Box

    private static final float BX = 0.48f, BY = 0.66f, BZ = 0.40f;
    private static final float WALL = 0.03f;
    private static final float THIRD = 1f / 3f;
    private static final int[] FULL = {255, 255, 255};
    private static final int[] INNER = {120, 92, 62};

    /**
     * Cardboard box. flapDegrees == 0 draws a closed, taped lid; anything above
     * zero draws an open box (inner walls) with two lid flaps rotated outwards.
     */
    private static void renderBox(class_4587 matrices, class_4588 vc, int light, float flapDegrees) {
        class_4587.class_4665 e = matrices.method_23760();
        // atlas: [0..1/3] long side, [1/3..2/3] short side with tape, [2/3..1] top with tape
        face(e, vc, light, FULL, 0, 0, 1, 0f, THIRD, 0f, 1f,
                -BX, BY, BZ, -BX, 0, BZ, BX, 0, BZ, BX, BY, BZ);
        face(e, vc, light, FULL, 0, 0, -1, 0f, THIRD, 0f, 1f,
                BX, BY, -BZ, BX, 0, -BZ, -BX, 0, -BZ, -BX, BY, -BZ);
        face(e, vc, light, FULL, 1, 0, 0, THIRD, 2 * THIRD, 0f, 1f,
                BX, BY, BZ, BX, 0, BZ, BX, 0, -BZ, BX, BY, -BZ);
        face(e, vc, light, FULL, -1, 0, 0, THIRD, 2 * THIRD, 0f, 1f,
                -BX, BY, -BZ, -BX, 0, -BZ, -BX, 0, BZ, -BX, BY, BZ);
        face(e, vc, light, FULL, 0, -1, 0, 0f, THIRD, 0f, 1f,
                -BX, 0, BZ, -BX, 0, -BZ, BX, 0, -BZ, BX, 0, BZ);

        if (flapDegrees <= 0f) {
            face(e, vc, light, FULL, 0, 1, 0, 2 * THIRD, 1f, 0f, 1f,
                    -BX, BY, -BZ, -BX, BY, BZ, BX, BY, BZ, BX, BY, -BZ);
            return;
        }

        // open box: darker inner walls, inner floor and the top rim
        float ix = BX - WALL, iz = BZ - WALL, fy = WALL;
        face(e, vc, light, INNER, 0, 0, -1, 0f, THIRD, 0f, 1f,
                -ix, BY, iz, -ix, fy, iz, ix, fy, iz, ix, BY, iz);
        face(e, vc, light, INNER, 0, 0, 1, 0f, THIRD, 0f, 1f,
                ix, BY, -iz, ix, fy, -iz, -ix, fy, -iz, -ix, BY, -iz);
        face(e, vc, light, INNER, -1, 0, 0, 0f, THIRD, 0f, 1f,
                ix, BY, iz, ix, fy, iz, ix, fy, -iz, ix, BY, -iz);
        face(e, vc, light, INNER, 1, 0, 0, 0f, THIRD, 0f, 1f,
                -ix, BY, -iz, -ix, fy, -iz, -ix, fy, iz, -ix, BY, iz);
        face(e, vc, light, INNER, 0, 1, 0, 0f, THIRD, 0f, 1f,
                -ix, fy, -iz, -ix, fy, iz, ix, fy, iz, ix, fy, -iz);
        float rimU0 = 0f, rimU1 = 0.02f;
        face(e, vc, light, FULL, 0, 1, 0, rimU0, rimU1, 0f, 1f,
                -BX, BY, iz, -BX, BY, BZ, BX, BY, BZ, BX, BY, iz);
        face(e, vc, light, FULL, 0, 1, 0, rimU0, rimU1, 0f, 1f,
                -BX, BY, -BZ, -BX, BY, -iz, BX, BY, -iz, BX, BY, -BZ);
        face(e, vc, light, FULL, 0, 1, 0, rimU0, rimU1, 0f, 1f,
                -BX, BY, -iz, -BX, BY, iz, -ix, BY, iz, -ix, BY, -iz);
        face(e, vc, light, FULL, 0, 1, 0, rimU0, rimU1, 0f, 1f,
                ix, BY, -iz, ix, BY, iz, BX, BY, iz, BX, BY, -iz);

        // flap hinged on the +Z edge (covers the +Z half of the lid)
        matrices.method_22903();
        matrices.method_22904(0.0, BY, BZ);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(flapDegrees));
        class_4587.class_4665 f1 = matrices.method_23760();
        face(f1, vc, light, FULL, 0, 1, 0, 2 * THIRD, 1f, 0.5f, 1f,
                -BX, 0, -BZ, -BX, 0, 0, BX, 0, 0, BX, 0, -BZ);
        matrices.method_22909();

        // flap hinged on the -Z edge
        matrices.method_22903();
        matrices.method_22904(0.0, BY, -BZ);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(-flapDegrees));
        class_4587.class_4665 f2 = matrices.method_23760();
        face(f2, vc, light, FULL, 0, 1, 0, 2 * THIRD, 1f, 0f, 0.5f,
                -BX, 0, 0, -BX, 0, BZ, BX, 0, BZ, BX, 0, 0);
        matrices.method_22909();
    }

    /** Corners: top-left, bottom-left, bottom-right, top-right. */
    private static void face(class_4587.class_4665 e, class_4588 vc, int light, int[] col,
                             float nx, float ny, float nz, float u0, float u1, float v0, float v1,
                             float x0, float y0, float z0, float x1, float y1, float z1,
                             float x2, float y2, float z2, float x3, float y3, float z3) {
        vertex(e, vc, x0, y0, z0, nx, ny, nz, u0, v0, col, light);
        vertex(e, vc, x1, y1, z1, nx, ny, nz, u0, v1, col, light);
        vertex(e, vc, x2, y2, z2, nx, ny, nz, u1, v1, col, light);
        vertex(e, vc, x3, y3, z3, nx, ny, nz, u1, v0, col, light);
    }

    // ------------------------------------------------------------------ common

    private static void vertex(class_4587.class_4665 e, class_4588 vc, float x, float y, float z,
                               float nx, float ny, float nz, float u, float v, int[] col, int light) {
        vc.method_22918(e.method_23761(), x, y, z)
                .method_1336(col[0], col[1], col[2], 255)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(light)
                .method_60831(e, nx, ny, nz);
    }
}
