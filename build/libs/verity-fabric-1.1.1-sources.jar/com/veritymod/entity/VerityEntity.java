package com.veritymod.entity;

import com.veritymod.sound.ModSounds;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1301;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_8111;

public class VerityEntity extends class_1296 {
    private static final class_2940<Boolean> IN_BOX = class_2945.method_12791(VerityEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> MOUTH_OPEN = class_2945.method_12791(VerityEntity.class, class_2943.field_13323);
    /** Network id of the player carrying Verity, or -1. */
    private static final class_2940<Integer> CARRIER_ID = class_2945.method_12791(VerityEntity.class, class_2943.field_13327);

    /** Length of the client-side "jump out of the box" animation, in ticks. */
    public static final int RELEASE_ANIM_TICKS = 36;
    /** Visual size of Verity while carried. */
    public static final float CARRY_SCALE = 0.5f;

    private int boxJumpCooldown;
    private int speakTicks;
    private int mouthTimer;
    private int greetingAge;
    private int serverReleaseTicks;
    @Nullable private UUID carrierUuid;

    // physics (server)
    private double airVelY;
    private boolean wasOnGround = true;

    // visuals (client)
    private int releaseAge = -1;
    private int landAge = -1000;
    private float landAmp;
    private double clientFallSpeed;
    private boolean clientWasOnGround = true;

    public VerityEntity(class_1299<? extends VerityEntity> type, class_1937 world) {
        super(type, world);
        method_5684(true);
        method_5971();
    }

    public static class_5132.class_5133 createVerityAttributes() {
        return method_26828()
                .method_26868(class_5134.field_23719, 0.28)
                .method_26868(class_5134.field_23717, 48.0);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(IN_BOX, true);
        builder.method_56912(MOUTH_OPEN, false);
        builder.method_56912(CARRIER_ID, -1);
    }

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(1, new FollowNearestPlayerGoal(this));
    }

    // ------------------------------------------------------------------ state

    public boolean isInBox() { return field_6011.method_12789(IN_BOX); }
    public boolean isMouthOpen() { return field_6011.method_12789(MOUTH_OPEN); }
    public boolean isCarried() { return field_6011.method_12789(CARRIER_ID) >= 0; }
    public int getCarrierId() { return field_6011.method_12789(CARRIER_ID); }

    @Nullable
    public class_1297 getCarrier() {
        int id = getCarrierId();
        return id < 0 ? null : method_37908().method_8469(id);
    }

    /** Ticks since the box was opened (client), or -1 when no animation is playing. */
    public float getReleaseAnim(float tickDelta) {
        if (releaseAge < 0) return -1f;
        float a = field_6012 - releaseAge + tickDelta;
        return a > RELEASE_ANIM_TICKS ? -1f : a;
    }

    /** Ticks since the last hard landing (client) and its strength, for squash. */
    public float getLandAnim(float tickDelta) { return field_6012 - landAge + tickDelta; }
    public float getLandAmp() { return landAmp; }

    /** Where a carried Verity's centre is: in front of the carrier, low and to the right. */
    public static class_243 carryPos(class_1657 p, float tickDelta) {
        class_243 eye = p.method_5836(tickDelta);
        class_243 fwd = class_243.method_1030(0.0f, p.method_5705(tickDelta));
        class_243 right = new class_243(-fwd.field_1350, 0.0, fwd.field_1352);
        return eye.method_1019(fwd.method_1021(0.75)).method_1019(right.method_1021(0.35)).method_1031(0.0, -0.6, 0.0);
    }

    @Nullable
    public static VerityEntity findCarriedBy(class_1657 player) {
        List<VerityEntity> list = player.method_37908().method_8390(VerityEntity.class,
                player.method_5829().method_1014(4.0), v -> v.getCarrierId() == player.method_5628());
        return list.isEmpty() ? null : list.get(0);
    }

    @Override
    public void method_5674(class_2940<?> data) {
        super.method_5674(data);
        // Only animate a live opening, not an already-open Verity that just came into view.
        if (method_37908().field_9236 && IN_BOX.equals(data) && !isInBox() && field_6012 > 2) {
            releaseAge = field_6012;
        }
    }

    private void releaseFromBox(class_1657 player) {
        if (!isInBox() || method_37908().field_9236) return;
        field_6011.method_12778(IN_BOX, false);
        // The merged greeting is 7.127 seconds long at 20 ticks per second.
        speakTicks = 143;
        greetingAge = 0;
        mouthTimer = 0;
        serverReleaseTicks = RELEASE_ANIM_TICKS;
        field_6011.method_12778(MOUTH_OPEN, false);
        method_37908().method_43128(null, method_23317(), method_23318(), method_23321(), ModSounds.VERITY_GREETING, class_3419.field_15254, 1.0f, 1.0f);
    }

    // --------------------------------------------------------- carry & place

    private void pickUp(class_1657 player) {
        carrierUuid = player.method_5667();
        field_6011.method_12778(CARRIER_ID, player.method_5628());
        method_5942().method_6340();
        method_5875(true);
        field_5960 = true;
        method_18799(class_243.field_1353);
        method_37908().method_43128(null, method_23317(), method_23318(), method_23321(), class_3417.field_15197, class_3419.field_15254, 0.8f, 0.8f);
    }

    /** Puts Verity down at the given bottom-centre position. */
    public void placeDown(class_243 pos) {
        if (method_37908().field_9236) return;
        carrierUuid = null;
        field_6011.method_12778(CARRIER_ID, -1);
        method_5875(false);
        field_5960 = false;
        method_5808(pos.field_1352, pos.field_1351 + 0.05, pos.field_1350, method_36454(), 0.0f);
        method_18800(0.0, -0.1, 0.0);
        field_6017 = 0.0f;
        airVelY = 0.0;
        method_37908().method_43128(null, method_23317(), method_23318(), method_23321(), class_3417.field_15148, class_3419.field_15254, 1.0f, 1.1f);
    }

    private void dropAtCurrentPosition() {
        placeDown(method_19538());
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (hand != class_1268.field_5808) return class_1269.field_5811;
        if (isInBox()) {
            releaseFromBox(player);
            return class_1269.field_5812;
        }
        if (!isCarried()) {
            if (!method_37908().field_9236) {
                if (serverReleaseTicks > 0 || findCarriedBy(player) != null) return class_1269.field_5811;
                pickUp(player);
            }
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    // ------------------------------------------------- damage & knockback

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        // Only /kill and the void can remove Verity.
        if (source.method_49708(class_8111.field_44869) || source.method_49708(class_8111.field_42347)) {
            if (isCarried()) dropAtCurrentPosition();
            return super.method_5643(source, amount);
        }
        if (method_37908().field_9236 || isCarried()) return false;

        if (source.method_5529() instanceof class_1657 player && isInBox()) {
            releaseFromBox(player);
            return false;
        }
        // No damage, but a real, bouncy push away from whatever hit her.
        class_1297 pusher = source.method_5526() != null ? source.method_5526() : source.method_5529();
        if (pusher != null && !isInBox()) {
            double dx = pusher.method_23317() - method_23317();
            double dz = pusher.method_23321() - method_23321();
            float strength = 0.55f;
            if (pusher.method_5624()) strength += 0.45f;
            method_6005(strength, dx, dz);
            method_18799(method_18798().method_1031(0.0, 0.12, 0.0));
            field_6037 = true;
            method_37908().method_43128(null, method_23317(), method_23318(), method_23321(), class_3417.field_14694, class_3419.field_15254, 0.8f, 1.2f);
        }
        return false;
    }

    @Override
    public boolean method_5679(class_1282 source) {
        return !(source.method_49708(class_8111.field_44869) || source.method_49708(class_8111.field_42347));
    }

    @Override
    public boolean method_5810() { return !isCarried(); }

    @Override
    public boolean method_5863() { return !isCarried() && super.method_5863(); }

    @Override
    public boolean method_5974(double distanceSquared) { return false; }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 damageSource) {
        return false;
    }

    // ----------------------------------------------------------------- tick

    @Override
    public void method_5773() {
        super.method_5773();
        lookAtNearestPlayer();

        if (method_37908().field_9236) {
            clientTick();
            return;
        }

        if (isCarried()) {
            class_1657 carrier = carrierUuid == null ? null : method_37908().method_18470(carrierUuid);
            if (carrier == null || !carrier.method_5805() || carrier.method_7325()) {
                dropAtCurrentPosition();
            } else {
                class_243 c = carryPos(carrier, 1.0f);
                method_5814(c.field_1352, c.field_1351 - 0.45 * CARRY_SCALE, c.field_1350);
                method_18799(class_243.field_1353);
                field_6017 = 0.0f;
            }
        } else {
            bouncePhysics();
        }

        if (serverReleaseTicks > 0) serverReleaseTicks--;

        if (isInBox()) {
            if (method_24828() && boxJumpCooldown-- <= 0) {
                method_18800(method_18798().field_1352, 0.42, method_18798().field_1350);
                field_6007 = true;
                boxJumpCooldown = 18;
            }
        } else if (speakTicks > 0) {
            greetingAge++;
            speakTicks--;
            if (isSpeechTick(greetingAge)) {
                if (++mouthTimer >= 3) {
                    mouthTimer = 0;
                    field_6011.method_12778(MOUTH_OPEN, !isMouthOpen());
                }
            } else {
                mouthTimer = 0;
                field_6011.method_12778(MOUTH_OPEN, false);
            }
            if (speakTicks == 0) field_6011.method_12778(MOUTH_OPEN, false);
        }
    }

    /** A rubber ball: hard landings bounce back with ~55% of the fall speed. */
    private void bouncePhysics() {
        if (!method_24828()) {
            airVelY = method_18798().field_1351;
        } else if (!wasOnGround && !isInBox() && airVelY < -0.25) {
            double up = -airVelY * 0.55;
            method_18800(method_18798().field_1352 * 0.85, up, method_18798().field_1350 * 0.85);
            field_6037 = true;
            float vol = (float) class_3532.method_15350(-airVelY, 0.3, 1.0);
            method_37908().method_43128(null, method_23317(), method_23318(), method_23321(), class_3417.field_15148, class_3419.field_15254, vol, 1.2f);
            airVelY = 0.0;
        }
        wasOnGround = method_24828();
    }

    /** Runs on both sides every tick so the face always points at the player. */
    private void lookAtNearestPlayer() {
        class_1657 target = method_37908().method_8604(method_23317(), method_23318(), method_23321(), 64.0, class_1301.field_6155);
        if (target == null) return;
        double dx = target.method_23317() - method_23317();
        double dz = target.method_23321() - method_23321();
        double dy = target.method_23320() - (method_23318() + 0.45);
        float yaw = (float) (class_3532.method_15349(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(class_3532.method_15349(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));
        method_36456(yaw);
        method_5636(yaw);
        method_5847(yaw);
        method_36457(class_3532.method_15363(pitch, -40.0f, 40.0f));
    }

    private void clientTick() {
        // landing squash detection
        double vy = method_23318() - field_6036;
        if (!method_24828()) {
            clientFallSpeed = vy;
        } else if (!clientWasOnGround && clientFallSpeed < -0.15 && !isCarried()) {
            landAge = field_6012;
            landAmp = (float) class_3532.method_15350(-clientFallSpeed * 0.8, 0.08, 0.35);
            clientFallSpeed = 0.0;
        }
        clientWasOnGround = method_24828();

        if (releaseAge < 0) return;
        int a = field_6012 - releaseAge;
        if (a == 2) {
            localSound(class_3417.field_14975, 1.0f, 1.2f);
        } else if (a == 4) {
            localSound(class_3417.field_15197, 1.0f, 0.7f);
            for (int i = 0; i < 14; i++) {
                method_37908().method_8406(class_2398.field_11203, method_23317(), method_23318() + 0.7, method_23321(),
                        (field_5974.method_43058() - 0.5) * 0.25, 0.12 + field_5974.method_43058() * 0.1, (field_5974.method_43058() - 0.5) * 0.25);
            }
            for (int i = 0; i < 8; i++) {
                method_37908().method_8406(class_2398.field_11207, method_23317(), method_23318() + 0.8, method_23321(),
                        (field_5974.method_43058() - 0.5) * 0.2, 0.15 + field_5974.method_43058() * 0.1, (field_5974.method_43058() - 0.5) * 0.2);
            }
        } else if (a == 20) {
            localSound(class_3417.field_14983, 1.0f, 0.9f);
            for (int i = 0; i < 24; i++) {
                method_37908().method_8406(class_2398.field_11203,
                        method_23317() + (field_5974.method_43058() - 0.5), method_23318() + field_5974.method_43058() * 0.7,
                        method_23321() + (field_5974.method_43058() - 0.5) * 0.8, 0.0, 0.03, 0.0);
            }
        }
    }

    private void localSound(class_3414 sound, float volume, float pitch) {
        method_37908().method_8486(method_23317(), method_23318(), method_23321(), sound, class_3419.field_15254, volume, pitch, false);
    }

    private static boolean isSpeechTick(int tick) {
        return (tick >= 10 && tick <= 66)
                || (tick >= 88 && tick <= 114)
                || (tick >= 124 && tick <= 140);
    }

    // ------------------------------------------------------------------ save

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10556("VerityInBox", isInBox());
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        if (nbt.method_10545("VerityInBox")) field_6011.method_12778(IN_BOX, nbt.method_10577("VerityInBox"));
        // A carried Verity is never saved as carried: it is simply put down where it was.
        field_6011.method_12778(CARRIER_ID, -1);
        method_5875(false);
        field_5960 = false;
    }

    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) { return null; }

    // ------------------------------------------------------------- follow AI

    /** Walks after the nearest player, keeping ~2.5 blocks of distance. */
    static class FollowNearestPlayerGoal extends class_1352 {
        private final VerityEntity verity;
        @Nullable private class_1657 target;
        private int recalc;

        FollowNearestPlayerGoal(VerityEntity verity) {
            this.verity = verity;
            method_6265(EnumSet.of(class_1352.class_4134.field_18405));
        }

        private boolean busy() {
            return verity.isInBox() || verity.isCarried() || verity.serverReleaseTicks > 0;
        }

        @Override
        public boolean method_6264() {
            if (busy()) return false;
            class_1657 p = verity.method_37908().method_8604(verity.method_23317(), verity.method_23318(), verity.method_23321(), 48.0, class_1301.field_6155);
            if (p == null || verity.method_5858(p) < 9.0) return false;
            target = p;
            return true;
        }

        @Override
        public boolean method_6266() {
            return !busy() && target != null && target.method_5805() && !target.method_7325()
                    && verity.method_5858(target) > 5.0;
        }

        @Override
        public void method_6269() { recalc = 0; }

        @Override
        public void method_6270() {
            target = null;
            verity.method_5942().method_6340();
        }

        @Override
        public void method_6268() {
            if (target == null || --recalc > 0) return;
            recalc = 10;
            double d2 = verity.method_5858(target);
            if (d2 > 28.0 * 28.0 && target.method_24828()) {
                // Too far behind: catch up like a pet.
                verity.method_5942().method_6340();
                verity.method_5808(target.method_23317(), target.method_23318(), target.method_23321(), verity.method_36454(), 0.0f);
                return;
            }
            verity.method_5942().method_6335(target, d2 > 100.0 ? 1.5 : 1.0);
        }
    }
}
